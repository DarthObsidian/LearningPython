//: c12s:ProxyPattern.cpp
#include <iostream>
#include <cassert>
using namespace std;

class Subject {
public:
    void f() {}
    void g() {}
    void h() {}
};

class Proxy : public Subject {
    Subject* pSubj;
public:
    Proxy(Subject* pSubj) {
        setSubject(pSubj);
    }
    void setSubject(Subject* pSubj) {
        assert(pSubj);
        this->pSubj = pSubj;
        cout << "installed " << (void*)pSubj) << endl;
    }
    void f() {
        pSubj->f();
    }
    void g() {
        pSubj->g();
    }
    void h() {
        pSubj->h();
    }
};

class Implementation1 : public Subject {
public:
    void f() {
        cout << "Implementation1::f()\n";
    }
    void g() {
        cout << "Implementation1::g()\n";
    }
    void h() {
        cout << "Implementation1::h()\n";
    }
};

class Implementation2 : public Subject {
public:
    void f() {
        cout << "Implementation2::f()\n";
    }
    void g() {
        cout << "Implementation2::g()\n";
    }
    void h() {
        cout << "Implementation2::h()\n";
    }
};

int main() {
    Implementation1* p1 = new Implementation1;
    Proxy p(p1);
    p.f();
    p.g();
    p.h();

    Implementation2* p2 = new Implementation2;
    p.setSubject(p2);
    delete p1;
    p.f();
    p.g();
    p.h();
    delete p2;
}

