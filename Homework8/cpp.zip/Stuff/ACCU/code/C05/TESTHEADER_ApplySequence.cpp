//: .\C05:TESTHEADER_ApplySequence.cpp
//: C05:ApplySequence.h
// From "Thinking in C++, Volume 2", by Bruce Eckel & Chuck Allison.
// (c) 1995-2004 MindView, Inc. All Rights Reserved.
// See source code use permissions stated in the file 'License.txt',
// distributed with the code package available at www.MindView.net.
// Apply a function to an STL sequence container.
// const, 0 arguments, any type of return value:
// const, 1 argument, any type of return value:
// const, 2 arguments, any type of return value:
// Non-const, 0 arguments, any type of return value:
// Non-const, 1 argument, any type of return value:
// Non-const, 2 arguments, any type of return value:
// Etc., to handle maximum likely arguments ///:~
#include"ApplySequence.h"
int main() {}
