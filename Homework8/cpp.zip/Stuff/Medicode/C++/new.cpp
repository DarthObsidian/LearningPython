class Circle{};

Circle* p = new Circle();
int* p2 = new int();

